-------- README
Para compilar o jogo e gerar o .jar, execute o seguinte comando em um terminal na pasta src:
$ make
Esse comando irá gerar o arquivo executável reversi.jar. Para executá-lo, execute em um terminal:
$ java -jar reversi.jar

A tela do jogo irá abrir. Para jogar, basta clicar na posição desejada para colocar a peça.

OBS: Para executar o jogo, é necessário um computador com Java 8 instalado. O trabalho foi testado no Ubuntu 16.04.5 com o java 1.8.0_191.
