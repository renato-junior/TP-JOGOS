package reversi;

/**
 *
 * @author Renato
 */
public class Reversi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GameController controller = new GameController();
        controller.initializeGame();
    }

}
